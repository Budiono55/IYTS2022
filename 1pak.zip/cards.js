const cards = [
    {
        "name": "day1",
        "title": "Day 1",
        "img": "./MICHJOJO.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day2",
        "title": "Day 2",
        "img": "../jaehee.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day3",
        "title": "Day 3",
        "img": "../jaehee_soojin.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day4",
        "title": "Day 4",
        "img": "../jihan.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day5",
        "title": "Day 5",
        "img": "../monday.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day6",
        "title": "Day 6",
        "img": "../soeun_zoa.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }, {
        "name": "day7",
        "title": "Day 7",
        "img": "../jiyoon.jpg",
        "description": "Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolores, recusandae?"
    }
]